import { Component,ViewChild } from '@angular/core';
import { NavController, AlertController,Content } from 'ionic-angular';
// import { Storage } from '@ionic/storage';
import { NativeStorage } from '@ionic-native/native-storage';
import { ToastProvider } from '../../providers/toast/toast';
@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    @ViewChild(Content) content: Content;

   
    whyfor;
    money;
    type = 't1';
    items = [];
    editMode = false;
    itemToEdit;
    status = 'active';
    delete = false;

    constructor(public navCtrl: NavController, public ToastProvider: ToastProvider, private alertCtrl: AlertController, private nativeStorage: NativeStorage) {

    }

    ionViewDidEnter() {
        this.refreshAccount();

    }
    refreshAccount() {
        let ref = this;
        this.nativeStorage.getItem('transactions')
            .then(
                val => {
                    let acc = [];
                    let tc = [];
                    if (val) {
                        acc = val.account;
                        acc.forEach((item, j) => {
                            if (item) {
                                tc.push(item);
                            }
                        });
                    }
                    ref.items = tc;
                    console.log(ref.items);
                },
                error => console.error(error)
            );
    }
    submit() {
        console.clear();
        if (this.whyfor && this.money) {
            this.nativeStorage.getItem('transactions').then(val => {
                console.log('value of transactions is:', val);
                this.setItem(val);
            }, err => {
                console.log('value of transactions is empty:', err);

                this.setItem();

                this.ToastProvider.showToast('خطا در ارتباط با حافظه!', 3000, 'bottom');

            });
        }
    }
    setItem(val = null) {
        console.log('try to submit fuck,', val);
        let acc = [];
        if (val) {
            acc = val.account;

        }

        if (this.editMode) {
            acc[this.itemToEdit] = {
                'money': this.money,
                'whyfor': this.whyfor,
                'type': this.type,
                'status': this.status
            };
            console.clear();
            console.log('setting new obj:', acc[this.itemToEdit])
        } else if (this.delete) {
            acc.splice(this.itemToEdit, 1);
        } else {
            acc.push({
                'money': this.money,
                'whyfor': this.whyfor,
                'type': this.type,
                'status': this.status
            });
        }
        console.log('last acc:', acc);
        this.nativeStorage.setItem('transactions', { 'account': acc }).then(val => {
            this.money = '';
            this.whyfor = '';
            this.type = 't1';
            this.status = '';
            this.itemToEdit = null;
            this.editMode = false;
            if (this.delete) {
                this.ToastProvider.showToast('با موفقیت حذف شد', 3000, 'bottom');
            } else {
                this.ToastProvider.showToast('با موفقیت ذخیره شد', 3000, 'bottom');
            }
            this.delete = false;
            this.refreshAccount();
        }, err => {
            console.log('err', err);
            this.ToastProvider.showToast('خطا در نوشتن در حافظه!', 3000, 'bottom');

        });
    }
    editThis(item, i) {
        this.whyfor = item.whyfor;
        this.money = item.money;
        if (item.type)
            this.type = item.type;
        else
            this.type = 't1';
        this.itemToEdit = i;
        this.editMode = true;
        this.scrollToTop();
    }
    cancel() {
        this.money = '';
        this.whyfor = '';
        this.type = 't1';
        this.status = '';
        this.itemToEdit = null;
        this.editMode = false;
    }
    convert(i) {
        return i.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    deleteConfirm(item, i) {
        let alert = this.alertCtrl.create({
            title: 'اطمینان از حذف',
            message: 'آیا از حذف اطمینان دارید؟',
            buttons: [
                {
                    text: 'خیر',
                    role: 'cancel',
                    handler: () => {
                        console.log('Cancel clicked');
                    }
                },
                {
                    text: 'بله',
                    handler: () => {
                        this.deleteItem(item, i);
                    }
                }
            ]
        });
        alert.present();
    }
    deleteItem(item, i) {
        this.whyfor = item.whyfor;
        this.money = item.money;
        this.itemToEdit = i;
        this.editMode = false;
        this.delete = true;
        this.submit();
    }
    scrollToTop() {
        this.content.scrollToTop();
      }
}
